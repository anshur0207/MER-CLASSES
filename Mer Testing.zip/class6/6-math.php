<?php  include ('../includes/header.php')
?><br><br><br>
<div class="container text-center text-danger">
	<h1>Maths</h1>
<div class="row">
	<div class="col-lg-3 col-md-6 col-xs-12">
		<div class="card" style="width:200px;">
			<div class="card-body">
				<h2 class="card-title text-center text-danger">Chapter 1</h2>&nbsp;&nbsp;&nbsp;&nbsp;
				<a href="https://drive.google.com/open?id=1L47pMsrzbwIImz2PaQHEevlWo2gqkQyK" class="btn btn-primary">DOWNLOAD</a>
			</div>
		</div>
	</div><div class="col-lg-3 col-md-6 col-xs-12">
		<div class="card" style="width:200px;">
			<div class="card-body">
				<h2 class="card-title text-center text-danger">Chapter 2</h2>&nbsp;&nbsp;&nbsp;&nbsp;
				<a href="https://drive.google.com/open?id=1AAybHBUGn9-6nNWFBc00bhmh6XaWyCTh" class="btn btn-primary">DOWNLOAD</a>
			</div>
		</div>
	</div>
	<div class="col-lg-3 col-md-6 col-xs-12">
		<div class="card" style="width:200px;">
			<div class="card-body">
				<h2 class="card-title text-center text-danger">Chapter 3</h2>&nbsp;&nbsp;&nbsp;&nbsp;
				<a href="https://drive.google.com/open?id=1zG_gZP8CdCocd9ePddDbHvkQAYulHJGa" class="btn btn-primary">DOWNLOAD</a>
			</div>
		</div>
	</div>
	<div class="col-lg-3 col-md-6 col-xs-12">
		<div class="card" style="width:200px;">
			<div class="card-body">
				<h2 class="card-title text-center text-danger">Chapter 4</h2>&nbsp;&nbsp;&nbsp;&nbsp;
				<a href="https://drive.google.com/open?id=1Rl4zU8kBw1d2fjxOCfsIAR3CME6uQlhG" class="btn btn-primary">DOWNLOAD</a>
			</div>
		</div>
	</div>
	<div class="col-lg-3 col-md-6 col-xs-12">
		<div class="card" style="width:200px;">
			<div class="card-body">
				<h2 class="card-title text-center text-danger">Chapter 5</h2>&nbsp;&nbsp;&nbsp;&nbsp;
				<a href="https://drive.google.com/open?id=1i90npR6IyzSgrQY-EHG5727AAKFCx0_1" class="btn btn-primary">DOWNLOAD</a>
			</div>
		</div>
	</div>
	<div class="col-lg-3 col-md-6 col-xs-12">
		<div class="card" style="width:200px;">
			<div class="card-body">
				<h2 class="card-title text-center text-danger">Chapter 6</h2>&nbsp;&nbsp;&nbsp;&nbsp;
				<a href="https://drive.google.com/open?id=1_XqADGWiieCHCJK9m4OgaYJJKTsykdSp" class="btn btn-primary">DOWNLOAD</a>
			</div>
		</div>
	</div>
	<div class="col-lg-3 col-md-6 col-xs-12">
		<div class="card" style="width:200px;">
			<div class="card-body">
				<h2 class="card-title text-center text-danger">Chapter 7</h2>&nbsp;&nbsp;&nbsp;&nbsp;
				<a href="https://drive.google.com/open?id=1PE5EuweZtAhtwZCCM9QWEGCKn4yOPyHJ" class="btn btn-primary">DOWNLOAD</a>
			</div>
		</div>
	</div>
	<div class="col-lg-3 col-md-6 col-xs-12">
		<div class="card" style="width:200px;">
			<div class="card-body">
				<h2 class="card-title text-center text-danger">Chapter 8</h2>&nbsp;&nbsp;&nbsp;&nbsp;
				<a href="https://drive.google.com/open?id=1_ppZ_o4zoC_6S2hEGJ5wtptHA6Gt8lbe" class="btn btn-primary">DOWNLOAD</a>
			</div>
		</div>
	</div>
	<div class="col-lg-3 col-md-6 col-xs-12">
		<div class="card" style="width:200px;">
			<div class="card-body">
				<h2 class="card-title text-center text-danger">Chapter 9</h2>&nbsp;&nbsp;&nbsp;&nbsp;
				<a href="https://drive.google.com/open?id=15G2axEfZuLp8H7ECg3ZdXf7boeKEytIw" class="btn btn-primary">DOWNLOAD</a>
			</div>
		</div>
	</div>
	<div class="col-lg-3 col-md-6 col-xs-12">
		<div class="card" style="width:200px;">
			<div class="card-body">
				<h2 class="card-title text-center text-danger">Chapter 10</h2>&nbsp;&nbsp;&nbsp;&nbsp;
				<a href="https://drive.google.com/file/d/11rRzQAoeA8r2_rmDh4DhbPlkPJaD7Psv/view?usp=sharing" class="btn btn-primary">DOWNLOAD</a>
			</div>
		</div>
	</div>
	<div class="col-lg-3 col-md-6 col-xs-12">
		<div class="card" style="width:200px;">
			<div class="card-body">
				<h2 class="card-title text-center text-danger">Chapter 11</h2>&nbsp;&nbsp;&nbsp;&nbsp;
				<a href="https://drive.google.com/open?id=15dLymTax8t83xDUcZNq-TxyK21BPXyqe" class="btn btn-primary">DOWNLOAD</a>
			</div>
		</div>
	</div>
	<div class="col-lg-3 col-md-6 col-xs-12">
		<div class="card" style="width:200px;">
			<div class="card-body">
				<h2 class="card-title text-center text-danger">Chapter 12</h2>&nbsp;&nbsp;&nbsp;&nbsp;
				<a href="https://drive.google.com/open?id=1Y7dSu_ywuQQbnrmBSrb3PtE-nhQtUzOB" class="btn btn-primary">DOWNLOAD</a>
			</div>
		</div>
	</div>
	<div class="col-lg-3 col-md-6 col-xs-12">
		<div class="card" style="width:200px;">
			<div class="card-body">
				<h2 class="card-title text-center text-danger">Chapter 13</h2>&nbsp;&nbsp;&nbsp;&nbsp;
				<a href="https://drive.google.com/open?id=1sgKsfvptfqdWzBGjphOvu-OPhpuVPFNT" class="btn btn-primary">DOWNLOAD</a>
			</div>
		</div>
	</div>
	<div class="col-lg-3 col-md-6 col-xs-12">
		<div class="card" style="width:200px;">
			<div class="card-body">
				<h2 class="card-title text-center text-danger">Chapter 14</h2>&nbsp;&nbsp;&nbsp;&nbsp;
				<a href="https://drive.google.com/open?id=19u-MiapeKZ3r7Plo41I_5Kb2OuaFdFpq" class="btn btn-primary">DOWNLOAD</a>
			</div>
		</div>
	</div><div class="col-lg-3 col-md-6 col-xs-12">
		<div class="card" style="width:200px;">
			<div class="card-body">
				<h2 class="card-title text-center text-danger">Answers</h2>&nbsp;&nbsp;&nbsp;&nbsp;
				<a href="https://drive.google.com/file/d/1HxFnb0VmzAVrsTSq8oSIsNHbw-N4t35K/view?usp=sharing" class="btn btn-primary">DOWNLOAD</a>
			</div>
		</div>
	</div>
</div>
</div>

	




<br><br><br>
<?php  include ('../includes/footer.php')
?>

