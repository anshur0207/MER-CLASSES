<!-- 
<br> Footer starts -->
    <footer  style="background-color: #2c292f">
        <div class="container" id="footer">
            <div class="row " >
                <div class="col-md-4 text-center text-md-left ">
                    
                    <div class="py-0">
                        <h3 class="my-4 text-white">About<span class="mx-2 font-italic text-warning ">MER</span></h3>
 
                        <p class="footer-links font-weight-bold">
                            <a class="text-white" href="courses.php">Courses</a>
                            |
                            <a class="text-white" href="#">Results</a>
                            |
                            <a class="text-white" href="#">Faculty</a>
                            |
                            <a class="text-white" href="contact.php">Contact Us</a>
                        </p>
                        <p class="text-light py-4 mb-4">&copy;2019 MER Coaching Classes Pvt. Ltd.</p>
                    </div>
                </div>
                
                <div class="col-md-4 text-white text-center text-md-left ">
                    <div class="py-2 my-4">
                        <div>
                            <p class="text-white"> <i class="fa fa-map-marker mx-2 "></i>
                             Kaushlya Kunj,<br>
                             Chandmari (EKAUNA) ,Ward No-27, Motihari East Champaran<br>
                            India</p>       
                        </div>
 
                        <div> 
                            <p><i class="fa fa-phone  mx-2 "></i> +91 7261083492</p>
                        </div>
                        <div>
                            <p><i class="fa fa-envelope  mx-2"></i><a href="mailto:merclasses2020@gmail.com">merclasses2020@gmail.com</a></p>
                        </div>  
                    </div>  
                </div>
                
                <div class="col-md-4 text-white my-4 text-center text-md-left ">
                    <section>
                        <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3565.9404674417815!2d84.8970366149922!3d26.65038848324127!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x39933551a914679d%3A0xd295342e72dcab66!2sM.E.R%20Classes!5e0!3m2!1sen!2sin!4v1588933580230!5m2!1sen!2sin" width="300" height="150" frameborder="0" style="border:0;" allowfullscreen="" aria-hidden="false" tabindex="0"></iframe>



                    </section>
                    <div class="py-2">
                        <a href="#"><i class="fab fa-facebook fa-2x text-primary mx-3"></i></a>
                        <a href="#"><i class="fab fa-google-plus fa-2x text-danger mx-3"></i></a>
                        <a href="#"><i class="fab fa-twitter fa-2x text-info mx-3"></i></a>
                        <a href="#"><i class="fab fa-youtube fa-2x text-danger mx-3"></i></a>
                    </div>
                </div>
            </div>
        </div>

     </footer>
     <!-- end of footer -->
 -->