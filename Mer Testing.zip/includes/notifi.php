<div class="content bg-light" > 
        <h1 class="header" align="center" style="font-family: 'Oswald', sans-serif; ">NOTIFICATIONS</h1>
        <marquee behaviour="scroll" direction="up" scrollamount="2" class="moving-body" style="font-family: 'Pridi', serif;">
          1)New Registration is going on.......<br>
          2)E-books are launching soon......<a href="isecure/login.php">click here</a>
          3)New Registration is going on.......<br>
           4)E-books are launching soon......<a href="isecure/login.php">click here</a>
           5)New Registration is going on.......<br>
           6)E-books are launching soon......<a href="isecure/login.php">click here</a>

        </marquee>
      </div>