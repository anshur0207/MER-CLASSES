There are two databases

1)merclasses
-> contact_table (for contact form)
2)phplearning
->users for login and signup







Free Hosting all details

username-anshur0202@gmail.com
password- Anshu@123
--------------------------------------------------------------------------------------------------------------
login for c-panel:-https://panel.freehosting.com:2222/
Username: merclas1
Password: QK5kku802a
--------------------------------------------------------------------------------------------------------------
Extra_features -> 
phpmyadmin- 
Username: merclas1_merclasses
Password: admin
--------------------------------------------------------------------------------------------------------------



Homepage Apply Online form
$link = mysqli_connect("localhost", "serverdatabase name", "password", "database name");


table name -> query

4 columns
1)fullname
2)email
3)phone
4)query




Ebook login

1)database connect

$username = 'root';
$password = '';
$dsn = 'mysql:host=localhost; dbname=merclasses';



table-> users

columns
1)user
2)password
 

Ebook Signup

$username = 'root';
$password = '';
$dsn = 'mysql:host=localhost; dbname=merclasses';


table-> ebbok

columns
1)user
2)email
3)password








